#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_fce864bc(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ee35a9ec() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_760d5081(inout vec4 vertex) {
    f_fce864bc(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ee35a9ec();
    }
    finalize();
}



void f_417e6dbe() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_889189be() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_42af8c81(inout vec4 vertex) {
    f_fce864bc(vertex);
    f_417e6dbe();
    finalize();
}

void f_93e0ee47(inout vec4 vertex) {
    f_fce864bc(vertex);
    f_ee35a9ec();
    f_889189be();
    finalize();
}

void f_31da7d20(inout vec4 vertex) {
    f_fce864bc(vertex);
    f_889189be();
    f_417e6dbe();
    finalize();
}

void f_8eeed83e(inout vec4 vertex) {
    f_ee35a9ec();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_fce864bc(vertex);
    finalize();
}

void f_bc4c8a78(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_417e6dbe();
    f_fce864bc(vertex);
    finalize();
}

void f_1482bc4c(inout vec4 vertex, float speed) {
    f_fce864bc(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_c87b7d7f(inout vec4 vertex) {
    f_fce864bc(vertex);
    f_ee35a9ec();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_760d5081(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ee35a9ec();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_fce864bc(vertex);
            f_ee35a9ec();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_93e0ee47(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_93e0ee47(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_8eeed83e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_8eeed83e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_1482bc4c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_c87b7d7f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_42af8c81(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_93e0ee47(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_31da7d20(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_8eeed83e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_bc4c8a78(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_1482bc4c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_42af8c81(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_93e0ee47(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_31da7d20(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_8eeed83e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_bc4c8a78(vertex);
        return;
    }
    

    
    f_fce864bc(vertex);
    f_ee35a9ec();
    finalize();
}